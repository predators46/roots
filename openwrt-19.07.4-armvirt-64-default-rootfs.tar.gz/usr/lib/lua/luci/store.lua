-- Copyright 2009 Steven Barth <steven@midlink.org>
-- Copyright 2009 Jo-Philipp Wich <jow@openwrt.org>
-- Licensed to the public under the Apache License 2.0.

local util = require "luci.util"
module("luci.store", util.threadlocal)